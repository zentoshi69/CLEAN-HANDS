#!/usr/bin/env bash
#
# bootstrap.sh — fresh Ubuntu VPS  →  fully live CLEAN HANDS, in one script.
#
# On a brand-new Ubuntu 22.04/24.04 server, as root:
#   nano bootstrap.sh      # paste this file, save (Ctrl-O, Enter, Ctrl-X)
#   sudo bash bootstrap.sh
#
# It installs everything, clones the repo, asks for your secrets, writes a locked
# .env, and starts all services behind HTTPS. You only do DNS + @BotFather after.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Please run as root:  sudo bash bootstrap.sh"; exit 1; }

DOMAIN="${DOMAIN:-app.cleanhands.fun}"
DIR=/opt/clean-hands

echo "================ CLEAN HANDS bootstrap ================"
echo "Domain: $DOMAIN   (change later if needed)"
echo

echo "==> [1/5] Installing system packages…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y git python3 python3-venv python3-pip sqlite3 ufw curl openssl \
  debian-keyring debian-archive-keyring apt-transport-https >/dev/null

echo "==> [2/5] Installing Caddy (auto-HTTPS)…"
if ! command -v caddy >/dev/null 2>&1; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y && apt-get install -y caddy >/dev/null
fi
ufw allow OpenSSH >/dev/null 2>&1 || true
ufw allow 80,443/tcp >/dev/null 2>&1 || true
yes | ufw enable >/dev/null 2>&1 || true

echo "==> [3/5] Getting the code…"
if [ ! -d "$DIR/.git" ] && [ ! -f "$DIR/deploy/deploy.sh" ]; then
  echo "   Paste a GitHub token (ghp_…) for the private CLEAN-HANDS repo,"
  echo "   or leave blank if you made the repo public:"
  read -rp "   token: " GH
  if [ -n "$GH" ]; then
    git clone "https://${GH}@github.com/zentoshi69/CLEAN-HANDS.git" "$DIR"
  else
    git clone "https://github.com/zentoshi69/CLEAN-HANDS.git" "$DIR"
  fi
fi
cd "$DIR"

echo "==> [4/5] Secrets (.env)…"
if [ ! -f .env ]; then
  cp .env.example .env
  set_kv() { sed -i "s|^$1=.*|$1=$2|" .env; }
  read -rp "   Admin Telegram numeric ID(s), comma-separated: " V; set_kv TG_ADMIN_IDS "$V"
  read -rp "   GUARDIAN bot token: " V; set_kv TG_BOT_TOKEN "$V"
  read -rp "   SCANNER bot token: " V; set_kv TG_SCANNER_TOKEN "$V"
  read -rp "   COMMUNITY bot token: " V; set_kv TG_COMMUNITY_TOKEN "$V"
  read -rp "   \$CLEAN mint (Enter to keep the pre-filled one): " V; [ -n "$V" ] && set_kv DEFAULT_TOKEN_MINT "$V"
  set_kv STAKE_ENV prod
  set_kv STAKE_SERVER_SECRET "$(openssl rand -hex 32)"
  set_kv STAKE_ADMIN_TOKEN "$(openssl rand -hex 32)"
  set_kv MINIAPP_URL "https://$DOMAIN"
  chmod 600 .env
  echo "   .env written and locked (chmod 600)."
fi

echo "==> [5/5] Building + starting all services…"
DOMAIN="$DOMAIN" bash deploy/deploy.sh

echo
echo "================ Done. ================"
echo "Next (your side):"
echo "  • DNS: point $DOMAIN -> this server's IP   (see deploy/DNS.md)"
echo "  • @BotFather: register the Mini App URL https://$DOMAIN/  (see deploy/BOTFATHER.md)"
echo "Verify any time:  bash $DIR/deploy/healthcheck.sh $DOMAIN"
